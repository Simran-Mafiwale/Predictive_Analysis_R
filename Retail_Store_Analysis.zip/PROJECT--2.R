library(tidymodels)
library(visdat)
library(tidyr)
library(car)
library(pROC)
library(ROCit)
getwd()
setwd("C:/jjjj/DA_R/Project_Datasets")

rs_train=read.csv("store_train.csv", stringsAsFactors = F)
rs_test=read.csv("store_test.csv", stringsAsFactors = F)


glimpse(rs_train)
vis_dat(rs_train)

## Pre-processing Data

# Id:Drop  (DONE)           
#sales0: To numeric (DONE)       
#sales1: To numeric  (DONE)       
#sales2: To numeric (DONE)
#sales3: To numeric (DONE)  
#sales4: To numeric (DONE) 
#country: Convert to factor or character and create dummies    (DONE)
#State: Convert to factor or character and create dummies (DONE)
#CouSub:Drop (DONE)
#countyname: Drop (same as country)
#storecode: Extract first 5 strings , convert to numeric. (DONE)
#Areaname: Drop (DONE)
#countytownname: Drop (DONE)
#population: To numeric also replace missing values with median (DONE)
#state_alpha:Drop (same as state) (DONE)
#store_Type: dummies  (DONE)
#store: Target Area


# Replacing the missing value with median
is.na(rs_train)
table(is.na(rs_train))

table(is.na(rs_train$population))

rs_train$population[is.na(rs_train$population)]=median(rs_train$population, na.rm = T)

#Storecode

rs_train$storecode

fn_storecode= function(x)
{
  fn= as.numeric(substr(x,1,5)=="METRO")
  return(fn)
}

# convert to factor


as.character(rs_train$country)
class(as.character(rs_train$country))

as.character(rs_train$State)

class(as.character(rs_train$State))

# as.factor(rs_test$country)
# class(as.factor(rs_test$country))
# 
# as.factor(rs_test$State)
# class(as.factor(rs_test$country))


dp_pipe= recipe(store~.,data = rs_train) %>% 
  update_role(Id, CouSub, Areaname, countytownname, 
              state_alpha, new_role = "drop_vars" ) %>%
  update_role(store_Type, new_role = "to_dummies") %>% 
  update_role(sales0,sales1,sales2,sales3,sales4, 
              population, new_role = "to_numeric") %>%
  step_rm(has_role("drop_vars")) %>% 
  step_mutate_at(storecode, fn= fn_storecode) %>% 
  step_mutate_at(has_role("to_numeric"), fn= as.numeric) %>% 
  step_unknown(has_role("to_dummies"), new_level = "__missing__") %>% 
  step_other(has_role("to_dummies"), threshold = 0.02, other = "__other__") %>% 
  step_novel(has_role("to_dummies")) %>% 
  step_impute_median(all_numeric(),- all_outcomes())
dp_pipe

dp_pipe=prep(dp_pipe)


train= bake(dp_pipe, new_data = NULL)

test= bake(dp_pipe, new_data = rs_test)


vis_dat(train)

#  

set.seed(2)
s= sample(1:nrow(train), 0.8*nrow(train))
train.build= train[s,]

train.test= train[-s,]


for_vif= lm(store~.-countyname
            -sales0
            -sales2
            -sales3, data = train.build)
sort(vif(for_vif), decreasing= T)[1:3]
vif(for_vif)
summary(for_vif)

# Build Logistic Regression Model

log_fit= glm(store~.-countyname
             -sales0
             -sales2
             -sales3, data = train.build,
            family = "binomial")
summary(log_fit)

# Removing insignificant Variables

log_fit= stats::step(log_fit)
summary(log_fit)

# Performance with AUC Score

val.score= predict(log_fit, newdata = train.test, type = "response")
pROC::auc(pROC::roc(train.test$store, val.score))
#Area under the curve: 0.8433


# Running the model on entire dataset

for_vif= lm(store~.-countyname
            -sales0
            -sales2
            -sales3, data = train)
sort(vif(for_vif), decreasing = T)[1:3]
vif(for_vif)
summary(for_vif)

# Build Final Model

log_fit.final= glm(store~., data = train,
            family = "binomial")
summary(log_fit.final)            

# Removing insignificant variable using step()

log_fit.final= stats::step(log_fit.final)
summary(log_fit.final)

# Prediction

train.score= predict(log_fit.final, newdata = test, type = "response")

train.score

# real= train$store               
# 
# cutoffs= seq(0.001, 0.999, 0.001)
# 
# cutoff_data= data.frame(cutoff= 99, sn=99, sp=99, KS= 99, F1= 99, M=99)
# 
# for (cutoff in cutoffs)
#   {
#   predicted= as.numeric(train.score>cutoff)
#   
#   TP= sum(real==1 & predicted==1)
#   TN= sum(real==0 & predicted==0)
#   FP= sum(real==0 & predicted==1)
#   FN= sum(real==1 & predicted==0)
#   
#   P= TP+FN
#   N= TN+FP
#   sn= TP/P
#   sp= TN/N
#   precision= TP/(TP+FN)
#   recall= sn
#   KS= (TP/P)-(FP/N)
#   F1= 2*precision*recall/(precision+recall)
#   M= (4*FP+FN)/5*(P+N)
#   
#   cutoff_data= rbind(cutoff_data, c(cutoff, sn, sp, KS, precision, F1, M))
# }
# 
# cutoff_data= cutoff_data[-1,]
# 
# # Best Cutoffs
# 
# my_cutoff= cutoff_data$cutoff[which.max(cutoff_data$KS)]
# my_cutoff

# Submission

test.pred.prob= predict(log_fit.final, newdata = test, type = "response")
write.csv(test.pred.prob, "Simran_Mafiwale_P2_Part2.csv", row.names=F)

test$pred_prob= test.pred.prob
table(is.na(test.pred.prob))


