getwd()
setwd("C:/jjjj/DA_R/Project_Datasets")

housing_train= read.csv("housing_train.csv", stringsAsFactors = F)
housing_test= read.csv("housing_test.csv", stringsAsFactors = F)


library(tidymodels)
library(visdat)
library(tidyr)
library(car)

# Visualize the datasets

vis_dat(housing_train)

glimpse(housing_train)

###
# "Suburb": Dummies (No NAs)
# "Address": Custom Function extract last 2 character    (no nas)   
# "Rooms": Convert to numeric        (no nas)
# "Type": Dummies        
# "Price" : Target variable (no nas   )   
# "Method"  Dummies (No NAs)     
# "SellerG" Dummies (No NAs)     
# "Distance"    Convert to numeric        (no nas) 
# "Postcode convert to character and create dummies 
# "Bedroom2"  convert to numeric replace missing values with median (DONE)
# "Bathroom"     convert to numeric replace missing values with median (DONE)
# "Car" convert to numeric replace missing values with median         (Done)
# "Landsize"  convert to numeric replace missing values with median   (Done)
# "BuildingArea" convert to numeric replace missing values with median (done)
# "YearBuilt"   convert to numeric replace missing values with median (done)
# "CouncilArea" dummies


table(is.na(housing_train$Postcode))
length(unique(i))
table(housing_train$Postcode)

i=substr(housing_train$Postcode,2,4)
i
class(i)

housing_train$Postcode= i


as.factor(housing_train$Postcode)
as.factor(housing_test$Postcode)

# Custom Function for Address

x= housing_train$Address
Address_new= substr(x, nchar(x)-1, nchar(x))
Address_new

housing_train$Address= Address_new


y= housing_test$Address
Address_new= substr(y, nchar(y)-1, nchar(y))
Address_new

housing_test$Address=Address_new


##

dp_pipe= recipe(Price~., data = housing_train) %>%
   update_role(Rooms,Distance,Bedroom2,
               Bathroom, Car, Landsize,
               BuildingArea,Postcode, YearBuilt,
               new_role = "to_numeric") %>%
  update_role(Suburb, Type, Address, Method,
               CouncilArea,SellerG,
               new_role = "to_dummies") %>%
   step_unknown(has_role("to_dummies"), new_level = "__missing__") %>% 
   step_other(has_role("to_dummies"), threshold = 0.02, other = "__other__") %>% 
   step_dummy(has_role("to_dummies")) %>%
   step_mutate_at(has_role("to_numeric"), fn= as.numeric) %>% 
   step_impute_median(all_numeric(),-all_outcomes())

dp_pipe=prep(dp_pipe)
train= bake(dp_pipe,new_data = NULL)   
test= bake(dp_pipe, new_data = housing_test)

vis_dat(train)
vis_dat(test)


## Sampling

set.seed(2)
s= sample(1:nrow(train), 0.8*nrow(train))
housing.build= train[s,]
housing.test= train[-s,]

# Model Building

fit= lm(Price~., data = housing.build)
sort(vif(fit), decreasing = T)
summary(fit)


fit=stats::step(fit)

summary(fit)
formula(fit)

fit= lm(Price~ Rooms + Distance + Postcode + Bedroom2 + Bathroom + Car + 
          Landsize + BuildingArea + YearBuilt + Suburb_Reservoir + 
          Suburb_Richmond + Address_Cr + Address_Ct + Address_Rd + 
          Address_St + Address_X__other__ + Type_t + Type_u + Method_S + 
          Method_SP + Method_VB + Method_X__other__ + SellerG_Biggin + 
          SellerG_hockingstuart + SellerG_Jellis + SellerG_Marshall + 
          SellerG_X__other__ + CouncilArea_Banyule + 
          CouncilArea_Bayside + CouncilArea_Boroondara + CouncilArea_Brimbank + 
          CouncilArea_Darebin + CouncilArea_Glen.Eira + CouncilArea_Hobsons.Bay + 
          CouncilArea_Manningham + CouncilArea_Maribyrnong + CouncilArea_Melbourne + 
          CouncilArea_Moonee.Valley + CouncilArea_Moreland + CouncilArea_Port.Phillip + 
          CouncilArea_Stonnington + CouncilArea_Yarra + CouncilArea_X__other__, data = housing.build)

summary(fit)
# Model Evaluation

housing.test.pred= predict(fit, newdata = housing.test)
errors= housing.test$Price-housing.test.pred


rmse= errors**2 %>% 
   mean() %>% 
  sqrt()
rmse

212467/rmse

mae= errors %>% 
  abs() %>% 
  mean()
mae


### Finalize Model

fit.final= lm(Price~., data = train)
sort(vif(fit.final), decreasing = T)[1:3]
summary(fit.final)

# Removing insignificant variable


fit.final= stats::step(fit.final)
summary(fit.final)
formula(fit.final)

fit.final= lm(Price~ Rooms + Distance + Postcode + Bedroom2 + Bathroom + Car + 
                Landsize + BuildingArea + YearBuilt + Suburb_Reservoir + 
                Suburb_Richmond + Address_Cr + Address_Ct + Address_Rd + 
                Address_St + Address_X__other__ + Type_t + Type_u + Method_S + 
                Method_SP + Method_VB + SellerG_Biggin + 
                SellerG_hockingstuart + SellerG_Jellis + SellerG_Marshall + 
                SellerG_Ray + SellerG_X__other__ + CouncilArea_Banyule + 
                CouncilArea_Bayside + CouncilArea_Boroondara + CouncilArea_Brimbank + 
                CouncilArea_Darebin + CouncilArea_Glen.Eira + CouncilArea_Hobsons.Bay + 
                CouncilArea_Manningham + CouncilArea_Maribyrnong + CouncilArea_Melbourne + 
                CouncilArea_Moonee.Valley + CouncilArea_Moreland + CouncilArea_Port.Phillip + 
                CouncilArea_Stonnington + CouncilArea_Yarra + CouncilArea_X__other__, data = train)

summary(fit.final)
# MAke prediction

test.pred= predict(fit.final, newdata = test)
write.csv(test.pred, "Simran_Mafiwale_P1_Part2.csv", row.names = F)

test$prediction= test.pred
View(test)
